﻿using System; 
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


//los objetos son la materializacion de na clase la clase es el molde de un objeto, ejemplo auto clase y rueda objeto

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            string hola = "Hola mundo";
            int edad;
            int numero = 5;
            float flotante = 54.52F; //Colocar F al final es para que identifique que es un Float sino lo concidera como double
            bool entrar = false;
            int numeroDia = (int)DateTime.Now.DayOfWeek; //le casteo 
            string nombreDeldia;


            Console.WriteLine(args[0]);
            Console.WriteLine(args[1]); //args= argumentos de consola esto es un array
            Console.WriteLine(hola);
            Console.WriteLine("El numero es {0} y el otro es {1} ", numero, flotante);

            Console.WriteLine("Ingrese su edad: ");
            edad= Int32.Parse(Console.ReadLine());
            if(edad>=18)
            {
                Console.WriteLine("Bienvenido");

            }
            else
            {
                Console.WriteLine("Rechazado");
            }


            switch(numeroDia)
            {
                case 0:
                    nombreDeldia = "Lunes";
                    break;
                case 1:
                    nombreDeldia = "Martes";
                        break;
                case 2:
                    nombreDeldia = "Miercoles";
                    break;
                case 3:
                    nombreDeldia = "Jueves";
                    break;
                case 4:
                    nombreDeldia = "Viernes";
                    break;
                case 5:
                    nombreDeldia = "Sabado";
                    break;
                case 6:
                    nombreDeldia = "Domingo";
                    break;
                default:
                    nombreDeldia = "No existe";
                    break;
 
            }

            Console.WriteLine("El nombre del dia {0}", nombreDeldia);
           Console.ReadLine();
        }
    }
}
