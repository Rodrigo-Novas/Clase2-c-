﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication2
{
    class Program
    {
        static void Main(string[] args)
        {

            int contador = 0;
            int nota;
            int sumAcum = 0;
            int cantidadAlum = 0;
            char salida;
            while(contador<10)
            {
                Console.WriteLine(contador);
                contador++;
            }


            contador = 0;

            do
            {
                Console.WriteLine(contador);

                contador += 1; //es lo mismo que el contador ++ solo que aca puedo ponerle que aumente por un numero especifico 1 o 2 o 3
            } while (contador < 10);



            Console.WriteLine("Ingrese nota alumnos x para terminar");
            do
            {
                nota = Int32.Parse(Console.ReadLine());


                sumAcum += nota;
                cantidadAlum++;
                Console.WriteLine("Desea salir? presione x");
                salida = Char.Parse( Console.ReadLine());
            } while (salida != 'x');

            Console.WriteLine("El total de notas es es: {0}", sumAcum);
            Console.WriteLine("La cantidad de notas es: {0}", cantidadAlum);
            Console.WriteLine("El promedio es: {0}", sumAcum / cantidadAlum);

            //for

            for(int i=0; i<=10; i ++)
            {
                if(i%2 == 0)Console.WriteLine(i); //saco pares ya que con el operador % sacoe l resto y si divido por 2 y el resto me da cero significa que es par
            }


            Console.ReadLine();
        }
    }
}
